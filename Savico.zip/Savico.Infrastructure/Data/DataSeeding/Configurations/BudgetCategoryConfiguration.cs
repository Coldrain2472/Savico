﻿namespace Savico.Infrastructure.Data.DataSeeding.Configurations
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using Savico.Infrastructure.Data.Models;

    //    public class BudgetCategoryConfiguration : IEntityTypeConfiguration<BudgetCategory>
    //    {
    //        public void Configure(EntityTypeBuilder<BudgetCategory> builder)
    //        {

    //        }
    //    }
}
