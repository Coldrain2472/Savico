﻿namespace Savico.Core.Models.ViewModels.Category
{
    public class CategoryExpenseViewModel
    {
        public string Name { get; set; } = null!;

        public decimal TotalAmount { get; set; }
    }
}
