﻿namespace Savico.Core.Models.ViewModels.Goal
{
    public class GoalContributeViewModel
    {
        public int GoalId { get; set; } // int Id?
        public decimal ContributionAmount { get; set; }
        public string? Currency { get; set; }
    }
}
